const mongoose = require('mongoose');
const morgan = require('morgan');
const express = require('express');
const Movie =require('./models/movies')

//express app
const app = express();

// connect to mongodb 
const dbURI = 'mongodb+srv://grupo3MisionTIC:peliculasBASH123@cluster0.rk43i.mongodb.net/Bash?retryWrites=true&w=majority'
mongoose.connect(dbURI, {useNewUrlParser: true, useUnifiedTopology: true})
    .then((result)=> app.listen(3000))
    .catch((err)=> console.log(err));

//ejs implement (register view engine)
app.set('view engine','ejs'); 

//middleware & static files
app.use(express.static('public'));
app.use(express.urlencoded({extended:true}));
app.use(morgan('dev'));


//routes

app.get('/', (req,res)=>{
    res.redirect('/inicio');
});

app.get('/inicio', (req,res)=>{
    res.render('index',{"title":" Home "})
})

app.get('/inicioSesion', (req,res)=>{
    res.render('inicioSesion', {title:'Inicio Sesion'});
});

/* app.get('/recomendaciones',(req,res)=>{
    res.render('recomendaciones',{title:'Recomendaciones'});
}) */

/* app.get('/newMovie',(req,res)=>{
    const movie=new Movie(req.body);
    movie.save();
}) */

//movies routes para pedir la pelicula de la base de datos
app.get('/all-movies',(req,res)=>{
    Movie.find()
    .then((result)=>{
        res.send(result);
    })
    .catch((err)=>{
        console.log(err);
    })
});

app.get('/all-recom', (req, res) => {
    Movie.find()
      .then((result) => {
        res.render('recomendaciones', { title: 'Recomendaciones' , movies: result });
      })
      .catch((err) => {
        console.log(err);
      });
  });

  app.get('/terror-recom', (req, res) => {
    Movie.findById('6154455092546090df8f7178')
      .then((result) => {
        res.render('recom', { title: 'Recomendaciones' , movies: result });
      })
      .catch((err) => {
        console.log(err);
      });
  });

  app.get('/drama-recom', (req, res) => {
    Movie.findById('61543f2c92546090df8f7174')
      .then((result) => {
        res.render('recom', { title: 'Recomendaciones' , movies: result });
      })
      .catch((err) => {
        console.log(err);
      });
  });

  app.get('/accion-recom', (req, res) => {
    Movie.findById('6154eb335a210f287fa5e8ad')
      .then((result) => {
        res.render('recom', { title: 'Recomendaciones' , movies: result });
      })
      .catch((err) => {
        console.log(err);
      });
  });

  app.get('/comedia-recom', (req, res) => {
    Movie.findById('615444e192546090df8f7177')
      .then((result) => {
        res.render('recom', { title: 'Recomendaciones' , movies: result });
      })
      .catch((err) => {
        console.log(err);
      });
  });




// 404 error page
app.use((req,res)=>{
    res.render('404',{title:'Error 404'});
    });


